const addPlayer = () => {
  fetch("http://localhost:3000/Player_Information", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      Name: document.getElementById("name").value,
      Country: document.getElementById("country").value,
      Team: document.getElementById("team").value,
      Age: document.getElementById("age").value,
      Skill: document.getElementById("skill").value,
    }),
  }).then((res) => {
    getInfo();
  });
};

function getInfo() {
  fetch("http://localhost:3000/Player_Information")
    .then((res) => res.json())
    .then((data) => {
      data.map((item) => {
        const row = document.createElement("tr");
        row.innerHTML = `
    
      <th>${item.Name}</th>
      <td>${item.Country}</td>
      <td>${item.Team}</td>
      <td>${item.Age}</td>
      <td>${item.Skill}</td>
      <td>
      <button type="button" class="btn btn-danger" onclick="DeleteItem(${item.id})">Delete</button>
      </td>`;
        document.getElementById("details").appendChild(row);
      });
    });
}
getInfo();

function DeleteItem(id) {
  fetch(`http://localhost:3000/Player_Information/${id}`, {
    method: "DELETE",
  }).then((res) => {
    getInfo();
  });
}
