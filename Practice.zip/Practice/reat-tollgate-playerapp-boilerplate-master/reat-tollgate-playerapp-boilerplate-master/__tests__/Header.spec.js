 
import Header from '../src/components/Header'

import Enzyme, { shallow, render, mount } from 'enzyme';
 
describe("header testing",()=>{
it('renders correctly enzyme', () => {
    const wrapper = shallow(<Header />)
  
    expect(toJson(wrapper)).toMatchSnapshot();
  });
})
