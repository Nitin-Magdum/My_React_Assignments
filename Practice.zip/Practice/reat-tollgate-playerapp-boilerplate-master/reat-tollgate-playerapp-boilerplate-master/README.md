## Instructions for running the Test cases

1. Run the unit testcases by `npm/yarn test`.
2. Refactor the code and run the unit testcases again until all the testcases are passing.
3. commit the code & push it to gitlab and submit in hobbes.
4. Refactor the code and submit in hobbes again unit the score is 100.  