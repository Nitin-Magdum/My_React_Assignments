import React, { useContext, useEffect, useState } from "react";
import axios from "axios";
import Header from "./Header";
export default function ShowPlayer() {
  const [data, setData] = useState([]);
  useEffect(async () => {
    const res = await axios.get("http://localhost:3000/players");
    setData(res.data);
  }, []);

  return (
    <div>
      <Header />
      <div className="data-table">
        <table className="table1">
          <tr>
            <th>Player Name</th>

            <th>Country</th>
            <th>Matches Played</th>
          </tr>

          {data &&
            data.map((item, err) => {
              return (
                <>
                  <tr>
                    <td>{item.name}</td>
                    <td>{item.country}</td>
                    <td>{item.matchesPlayed}</td>
                  </tr>
                </>
              );
            })}
        </table>
      </div>
    </div>
  );
}
