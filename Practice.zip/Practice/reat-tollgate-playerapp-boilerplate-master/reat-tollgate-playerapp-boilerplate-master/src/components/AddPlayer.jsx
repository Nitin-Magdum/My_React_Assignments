import React, { Component } from "react";
import { PlayerContext } from "../data/PlayerContext";
import axios from "axios";
import Header from "./Header";

export default class AddPlayer extends Component {
  constructor(props) {
    super(props);
    this.state = {
      Name: "",
      Country: "",
      matchPlayed: "",
    };
  }
  static contextType = PlayerContext;
  submitHandler = async (e) => {
    e.preventDefault();
    const user = this.context;
    let data = {
      name: this.state.Name,
      country: this.state.Country,
      matchesPlayed: this.state.matchPlayed,
    };
    const res = await axios.post("http://localhost:3000/players", data);
    console.log(res);

    window.location.href = "/show";
  };

  render() {
    return (
      <div>
        <Header/>
        {/* display form to accept name,country and matchesPlayed  of a player */}
        <form onSubmit={this.submitHandler}>
          <div className="add">
            <div className="name">
              <input
                type="text"
                placeholder="Enter name here..."
                value={this.state.Name}
                onChange={(e) => this.setState({ Name: e.target.value })}
              />
            </div>
            <div className="name">
              <input
                type="text"
                placeholder="Enter Country here..."
                value={this.state.Country}
                onChange={(e) => this.setState({ Country: e.target.value })}
              />
            </div>

            <div className="name">
              <input
                type="text"
                placeholder=" No. of match here.."
                value={this.state.matchPlayed}
                onChange={(e) => this.setState({ matchPlayed: e.target.value })}
              />
            </div>
            <div className="push">
              <button className="btn">Submit</button>
            </div>
          </div>
        </form>
      </div>
    );
  }
}
AddPlayer.contextType = PlayerContext;
