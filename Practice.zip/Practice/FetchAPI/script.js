async function getData() {
  await fetch("https://jsonplaceholder.typicode.com/photos")
    .then((res) => res.json())
    .then((data) => console.log(data));
  console.log("Task finished");
}

getData();
